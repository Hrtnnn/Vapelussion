Nama Aplikasi : Vapelussion
<br>
Deskrips Aplikasi yaitu membuat aplikasi berbasis android dengan tujuan untuk mempermudahkan dalam penjualan toko vape saya
<br>
Expo Api : status bar , Navigation Bar , Fonts



Nama : M. Herton Amarta Buana
NIM : 120140182
